<?php
class Home extends CI_controller{
    public function index(){
        // Merender method atau property yang
        $this->load->view('home/index');
    }
}
?>