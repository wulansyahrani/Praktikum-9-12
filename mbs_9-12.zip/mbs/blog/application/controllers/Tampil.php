<?php
class Tampil extends CI_controller{
    public function index(){
        // Load model
        $this->load->model('mahasiswa_model');
        $mahasiswa = $this->mahasiswa_model->getall();
        $data['mahasiswa'] = $mahasiswa;

        // Render view
        $this->load->view('layouts/header');
        $this->load->view('mahasiswa/tampil', $data);
        $this->load->view('layouts/footer');
    }

    public function dosen(){
            // akses model dosen
            $this->load->model('dosen_model');
            $dosen = $this->dosen_model->getAll();
            $data['dosen'] = $dosen;
            
            // render data dan kirim data ke dalam view
            $this->load->view('layouts/header');
            $this->load->view('dosen/index', $data);
            $this->load->view('layouts/footer');
        
    }

    public function matakuliah(){
        // akses model matakuliah
        $this->load->model('matakuliah_model');
        $matakuliah = $this->matakuliah_model->getAll();
        $data['matakuliah'] = $matakuliah;
        
        // render data dan kirim data ke dalam view
        $this->load->view('layouts/header');
        $this->load->view('matakuliah/index', $data);
        $this->load->view('layouts/footer');
    }
}
?>